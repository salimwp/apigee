const IS_DISABLED = false;

export default IS_DISABLED;
