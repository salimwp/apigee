import { combineReducers } from 'redux';

const createReducer = reducers => combineReducers(reducers);

export default createReducer;
