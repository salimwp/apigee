export const DIMENSION = 750;
export const SIZE = 100;
export const ACCEPTED_FORMAT = ['image/jpeg', 'image/png', 'image/svg+xml'];
