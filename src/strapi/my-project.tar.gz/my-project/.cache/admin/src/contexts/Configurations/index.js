import { createContext } from 'react';

const ConfigurationsContext = createContext({});

export default ConfigurationsContext;
